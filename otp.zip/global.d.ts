declare module 'jssip-node-websocket';
// declare module 'telegraf';
